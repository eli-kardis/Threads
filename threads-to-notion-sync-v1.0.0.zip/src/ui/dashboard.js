/**
 * Dashboard 페이지 로직 - Threads 통계
 */

let dailyChart = null;
let ratioChart = null;
let currentPeriod = 7;

/**
 * 초기화
 */
async function init() {
  setupEventListeners();
  await loadDashboardData();
}

/**
 * 이벤트 리스너 설정
 */
function setupEventListeners() {
  document.getElementById('refreshBtn').addEventListener('click', loadDashboardData);
  document.getElementById('settingsBtn').addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });

  // 기간 선택 탭
  document.querySelectorAll('.period-tab').forEach(btn => {
    btn.addEventListener('click', (e) => {
      document.querySelectorAll('.period-tab').forEach(b => b.classList.remove('active'));
      e.target.classList.add('active');
      currentPeriod = parseInt(e.target.dataset.period);
      loadDashboardData();
    });
  });
}

/**
 * 대시보드 데이터 로드
 */
async function loadDashboardData() {
  try {
    // 사용자 정보, 인사이트, 동기화 기록 동시 조회
    const [userInfo, insights, history] = await Promise.all([
      chrome.runtime.sendMessage({ type: 'TEST_CONNECTIONS' }),
      chrome.runtime.sendMessage({ type: 'GET_ACCOUNT_INSIGHTS', period: currentPeriod }),
      chrome.runtime.sendMessage({ type: 'GET_SYNC_HISTORY', limit: 100 })
    ]);

    // 사용자 이름 표시
    if (userInfo?.threads?.user?.username) {
      document.getElementById('usernameSubtitle').textContent =
        `@${userInfo.threads.user.username}의 계정 인사이트`;
    }

    updateStatsCards(insights);
    updateCharts(insights, history);
    updateHistoryTable(history);
  } catch (error) {
    console.error('Failed to load dashboard data:', error);
  }
}

/**
 * 통계 카드 업데이트
 */
function updateStatsCards(insights) {
  document.getElementById('viewsCount').textContent = formatNumber(insights.views || 0);
  document.getElementById('likesCount').textContent = formatNumber(insights.likes || 0);
  document.getElementById('repliesCount').textContent = formatNumber(insights.replies || 0);
  document.getElementById('repostsCount').textContent = formatNumber(insights.reposts || 0);
  document.getElementById('quotesCount').textContent = formatNumber(insights.quotes || 0);
  document.getElementById('followersCount').textContent = formatNumber(insights.followers_count || 0);
}

/**
 * 숫자 포맷팅 (1000 → 1K)
 */
function formatNumber(num) {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + 'M';
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'K';
  }
  return num.toLocaleString();
}

/**
 * 차트 업데이트
 */
function updateCharts(insights, history) {
  updateDailyChart(history);
  updateRatioChart(insights);
}

/**
 * 일별 조회수 현황 차트 (게시글 작성 수 기준)
 */
function updateDailyChart(history) {
  const ctx = document.getElementById('dailyChart').getContext('2d');

  // 최근 7일 게시글 수 계산
  const dailyData = getLast7DaysData(history);

  if (dailyChart) {
    dailyChart.destroy();
  }

  dailyChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: dailyData.labels,
      datasets: [{
        label: '게시글',
        data: dailyData.counts,
        backgroundColor: 'rgba(31, 58, 95, 0.8)',
        borderRadius: 6
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: false
        }
      },
      scales: {
        x: {
          grid: {
            display: false
          }
        },
        y: {
          beginAtZero: true,
          ticks: {
            stepSize: 1
          }
        }
      }
    }
  });
}

/**
 * 조회수 대비 팔로워 비율 차트
 */
function updateRatioChart(insights) {
  const ctx = document.getElementById('ratioChart').getContext('2d');

  if (ratioChart) {
    ratioChart.destroy();
  }

  const views = insights.views || 0;
  const followers = insights.followers_count || 0;

  if (views === 0 && followers === 0) {
    ratioChart = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: ['데이터 없음'],
        datasets: [{
          data: [1],
          backgroundColor: ['#E5E7EB'],
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom'
          }
        }
      }
    });
    return;
  }

  ratioChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['조회수', '팔로워'],
      datasets: [{
        data: [views, followers * 100], // 팔로워를 시각적으로 비교 가능하게 스케일링
        backgroundColor: [
          'rgba(31, 58, 95, 0.8)',
          'rgba(16, 185, 129, 0.8)'
        ],
        borderWidth: 0,
        hoverOffset: 4
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '70%',
      plugins: {
        legend: {
          position: 'bottom'
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              if (context.label === '팔로워') {
                return `팔로워: ${formatNumber(followers)}`;
              }
              return `조회수: ${formatNumber(views)}`;
            }
          }
        }
      }
    }
  });
}

/**
 * 최근 7일 데이터 계산
 */
function getLast7DaysData(history) {
  const labels = [];
  const counts = [];

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  for (let i = 6; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(today.getDate() - i);

    const dayLabel = i === 0 ? '오늘' : i === 1 ? '어제' : `${date.getMonth() + 1}/${date.getDate()}`;
    labels.push(dayLabel);

    const dayStart = new Date(date);
    const dayEnd = new Date(date);
    dayEnd.setDate(dayEnd.getDate() + 1);

    // 해당 날짜에 동기화된 게시글 수
    const dayCount = history.filter(item => {
      const itemDate = new Date(item.timestamp);
      return itemDate >= dayStart && itemDate < dayEnd && item.status === 'success';
    }).length;

    counts.push(dayCount);
  }

  return { labels, counts };
}

/**
 * 히스토리 테이블 업데이트 (스레드 기록)
 */
function updateHistoryTable(history) {
  const tbody = document.getElementById('historyTableBody');

  // 성공한 것만 필터링
  const successHistory = history.filter(h => h.status === 'success');

  if (!successHistory || successHistory.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="4" class="empty-state">동기화된 스레드가 없습니다</td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = successHistory.slice(0, 20).map(item => `
    <tr>
      <td>${item.title || `Thread ${item.threadId?.slice(0, 8) || 'Unknown'}`}</td>
      <td>
        <span class="status-badge">✓ 게시 완료</span>
      </td>
      <td>${formatRelativeTime(item.timestamp)}</td>
      <td>
        ${item.notionPageId
          ? `<a href="https://notion.so/${item.notionPageId.replace(/-/g, '')}" target="_blank" style="color: #1F3A5F;">열기</a>`
          : '-'
        }
      </td>
    </tr>
  `).join('');
}

/**
 * 상대 시간 포맷
 */
function formatRelativeTime(timestamp) {
  if (!timestamp) return '알 수 없음';

  const date = new Date(timestamp);
  const now = new Date();
  const diffMs = now - date;
  const diffSec = Math.floor(diffMs / 1000);
  const diffMin = Math.floor(diffSec / 60);
  const diffHour = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHour / 24);

  if (diffSec < 60) return '방금 전';
  if (diffMin < 60) return `${diffMin}분 전`;
  if (diffHour < 24) return `${diffHour}시간 전`;
  if (diffDay < 7) return `${diffDay}일 전`;

  return date.toLocaleDateString('ko-KR');
}

// 초기화
document.addEventListener('DOMContentLoaded', init);
